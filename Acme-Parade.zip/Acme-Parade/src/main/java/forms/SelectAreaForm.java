
package forms;

import java.util.Collection;

public class SelectAreaForm {

	private Collection<String>	areas;

	public Collection<String> getAreas() {
		return this.areas;
	}
	public void setAreas(final Collection<String> areas) {
		this.areas = areas;
	}

}
